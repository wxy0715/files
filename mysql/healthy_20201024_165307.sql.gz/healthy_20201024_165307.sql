-- MySQL dump 10.13  Distrib 8.0.20, for Linux (x86_64)
--
-- Host: localhost    Database: healthy
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lcw_case`
--

DROP TABLE IF EXISTS `lcw_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcw_case` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '姓名',
  `identity` varchar(255) NOT NULL DEFAULT '' COMMENT '身份证号码',
  `age` int NOT NULL DEFAULT '0' COMMENT '年龄',
  `sex` tinyint(1) NOT NULL COMMENT '0:男1:女',
  `medicalnumber` varchar(255) NOT NULL COMMENT '医保卡号',
  `depart` varchar(255) NOT NULL DEFAULT '' COMMENT '科室',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '病情描述',
  `creator` varchar(255) NOT NULL DEFAULT '' COMMENT '病例创建者',
  `createtime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lcw_case`
--

LOCK TABLES `lcw_case` WRITE;
/*!40000 ALTER TABLE `lcw_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `lcw_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lcw_file`
--

DROP TABLE IF EXISTS `lcw_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcw_file` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '姓名',
  `sex` tinyint(1) NOT NULL COMMENT '性别（男0，女1）',
  `age` int NOT NULL COMMENT '年龄',
  `birth` varchar(255) NOT NULL COMMENT '出生日期',
  `identity` varchar(255) NOT NULL COMMENT '身份证号',
  `nation` varchar(255) NOT NULL COMMENT '民族',
  `phone` varchar(255) NOT NULL COMMENT '手机',
  `email` varchar(255) NOT NULL COMMENT '邮箱',
  `province` varchar(255) NOT NULL COMMENT '省',
  `city` varchar(255) NOT NULL COMMENT '市',
  `area` varchar(255) NOT NULL COMMENT '县/区',
  `work` varchar(255) NOT NULL COMMENT '工作单位',
  `edu` varchar(255) NOT NULL COMMENT '文化程度',
  `profession` varchar(255) NOT NULL COMMENT '职业类型',
  `marital` tinyint(1) NOT NULL COMMENT '婚姻状况（未婚0，已婚1，离异2，保密3）',
  `medicalnumber` int NOT NULL COMMENT '医保卡号',
  `pre_history` varchar(255) NOT NULL COMMENT '既往病史',
  `drug_history` varchar(255) NOT NULL COMMENT '药物过敏',
  `family_history` varchar(255) NOT NULL COMMENT '家族遗传史',
  `bloodtype` varchar(255) NOT NULL COMMENT '血型',
  `RHbloodtype` varchar(255) NOT NULL COMMENT 'RH阴性',
  `paymed` varchar(255) NOT NULL COMMENT '支付方式',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lcw_file`
--

LOCK TABLES `lcw_file` WRITE;
/*!40000 ALTER TABLE `lcw_file` DISABLE KEYS */;
INSERT INTO `lcw_file` VALUES (8,'二哥',1,18,'2020年05月17日','340826199806201052','1','18955007261','123@qq.com','110000_2_0','110100_14_0','110102','无','1','无',4,123,'无','无','无','A型','不详','1',''),(9,'里斯',1,123,'2020年05月10日','340826199806201053','1','15155617688','123@qq.com','110000_2_0','110200_2_1','110228','无','1','无',1,123,'无','无','无','A型','不详','1','无'),(10,'王星宇',1,22,'2020年06月18日','341122199907154412','1','18955007265','3155@qq.com','150000_12_4','150100_9_0','150103','无','7','无',1,123123,'无','无','无','A型','否','1','无');
/*!40000 ALTER TABLE `lcw_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lcw_medicine`
--

DROP TABLE IF EXISTS `lcw_medicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcw_medicine` (
  `id` int NOT NULL AUTO_INCREMENT,
  `number` int NOT NULL COMMENT '编号',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `count` int NOT NULL COMMENT '库存量',
  `price` double(10,0) NOT NULL COMMENT '价格',
  `type` tinyint(1) NOT NULL COMMENT '类型（中药0 西药1）',
  `description` varchar(255) NOT NULL COMMENT '疗效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lcw_medicine`
--

LOCK TABLES `lcw_medicine` WRITE;
/*!40000 ALTER TABLE `lcw_medicine` DISABLE KEYS */;
INSERT INTO `lcw_medicine` VALUES (1,100001,'三九感冒灵',999,10,1,'感冒灵'),(2,100002,'阿莫西林',9999,5,1,'消炎药');
/*!40000 ALTER TABLE `lcw_medicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lcw_menu`
--

DROP TABLE IF EXISTS `lcw_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcw_menu` (
  `id` int NOT NULL COMMENT 'ID',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '名称',
  `icon` varchar(255) NOT NULL DEFAULT '',
  `href` varchar(255) NOT NULL DEFAULT '',
  `spread` tinyint(1) DEFAULT NULL COMMENT '0:true,1:false',
  `parent_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lcw_menu`
--

LOCK TABLES `lcw_menu` WRITE;
/*!40000 ALTER TABLE `lcw_menu` DISABLE KEYS */;
INSERT INTO `lcw_menu` VALUES (1,'首页','icon-computer','page/main?type=0',0,0),(2,'用户管理','icon-text','',0,0),(3,'用户列表','&#xe61c;','page/links/linksList',0,2),(4,'个人建档','&#xe609;','page/links/linksAdd',0,2),(5,'档案管理','&#xe64c;','',0,0),(6,'档案列表','&#xe61c;','page/archives/Archives',0,5),(7,'就诊列表','&#xe609;','page/archives/visitList?type=-1',0,5),(8,'体检列表','&#xe609;','page/archives/peisAllList',0,5),(9,'就诊管理','&#xe631;','',0,0),(10,'查询信息','&#xe61c;','page/visitmanager/search',0,9),(11,'就诊操作','&#xe609;','page/visitmanager/addoperation',0,9),(12,'诊断记录','&#xe609;','page/visitmanager/visitRecord',0,9),(13,'体检信息','&#xe609;','page/visitmanager/peis',0,9),(14,'体检记录','&#xe609;','page/visitmanager/peisList',0,9),(15,'药品管理','&#xe632;','page/drugmanager/drugList',0,0),(16,'个人档案','&#xe630;','page/user/selfArchives',0,0),(17,'个人中心','&#xe630;','page/user/userInfo',0,0);
/*!40000 ALTER TABLE `lcw_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lcw_peis`
--

DROP TABLE IF EXISTS `lcw_peis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcw_peis` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id主键',
  `length` varchar(11) NOT NULL DEFAULT '' COMMENT '身高（厘米）',
  `weight` varchar(11) NOT NULL DEFAULT '' COMMENT '体重（千克）',
  `left_eye` varchar(11) NOT NULL DEFAULT '' COMMENT '左眼视力',
  `right_eye` varchar(11) NOT NULL DEFAULT '' COMMENT '右眼视力',
  `heart` varchar(11) NOT NULL DEFAULT '' COMMENT '心率（次/分钟）',
  `m_voice` int NOT NULL DEFAULT '0' COMMENT '杂音（0无，1有）',
  `tong_a` int NOT NULL DEFAULT '0' COMMENT '桶状胸(0否，1是)',
  `voice_a` int NOT NULL DEFAULT '0' COMMENT '呼吸音（0正常，1异常）',
  `voice_b` int NOT NULL DEFAULT '0' COMMENT '罗音(0无，1干罗音，2湿罗音，3其他)',
  `creator_id` int NOT NULL COMMENT '创建者的id',
  `identity` varchar(255) NOT NULL COMMENT '体检者身份证号码',
  `creat_time` datetime NOT NULL COMMENT '创建的时间',
  `result` varchar(255) NOT NULL DEFAULT '' COMMENT '体检结果',
  `pre_history` varchar(255) DEFAULT NULL COMMENT '既往病史',
  `drug_history` varchar(255) DEFAULT NULL COMMENT '药物过敏史',
  `family_history` varchar(255) DEFAULT NULL COMMENT '家族遗传史',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lcw_peis`
--

LOCK TABLES `lcw_peis` WRITE;
/*!40000 ALTER TABLE `lcw_peis` DISABLE KEYS */;
INSERT INTO `lcw_peis` VALUES (5,'','60','5.4','5.4','',0,0,0,0,34,'340826199806201053','2020-05-20 22:56:44','正常',NULL,NULL,NULL);
/*!40000 ALTER TABLE `lcw_peis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lcw_project`
--

DROP TABLE IF EXISTS `lcw_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcw_project` (
  `id` int NOT NULL AUTO_INCREMENT,
  `projects_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lcw_project`
--

LOCK TABLES `lcw_project` WRITE;
/*!40000 ALTER TABLE `lcw_project` DISABLE KEYS */;
INSERT INTO `lcw_project` VALUES (1,'B超'),(2,'CT'),(3,'核磁共振'),(4,'血尿常规'),(5,'血压'),(6,'血脂'),(7,'血糖'),(8,'肝肾功能');
/*!40000 ALTER TABLE `lcw_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lcw_role`
--

DROP TABLE IF EXISTS `lcw_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcw_role` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `rolename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lcw_role`
--

LOCK TABLES `lcw_role` WRITE;
/*!40000 ALTER TABLE `lcw_role` DISABLE KEYS */;
INSERT INTO `lcw_role` VALUES (1,'管理员'),(2,'医生'),(3,'操作员'),(4,'普通用户');
/*!40000 ALTER TABLE `lcw_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lcw_role_menu`
--

DROP TABLE IF EXISTS `lcw_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcw_role_menu` (
  `role_id` int NOT NULL,
  `menu_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lcw_role_menu`
--

LOCK TABLES `lcw_role_menu` WRITE;
/*!40000 ALTER TABLE `lcw_role_menu` DISABLE KEYS */;
INSERT INTO `lcw_role_menu` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,15),(2,9),(2,10),(2,11),(2,12),(2,13),(2,14),(3,2),(3,4),(3,13),(3,14),(4,16),(1,17),(2,17),(3,17),(4,17);
/*!40000 ALTER TABLE `lcw_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lcw_treatment`
--

DROP TABLE IF EXISTS `lcw_treatment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcw_treatment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creator_id` int NOT NULL,
  `identity` varchar(255) NOT NULL,
  `create_time` datetime NOT NULL,
  `projects` varchar(255) DEFAULT NULL COMMENT '检查项目',
  `medicine` varchar(255) DEFAULT NULL COMMENT '用药',
  `further_visit` tinyint(1) DEFAULT NULL COMMENT '复诊（0 需要  1 不需要）',
  `in_hospital` tinyint(1) DEFAULT NULL COMMENT '住院（0需要 1不需要）',
  `symptom` varchar(255) NOT NULL COMMENT '主要症状',
  `doctors_advice` varchar(255) DEFAULT NULL COMMENT '医嘱',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lcw_treatment`
--

LOCK TABLES `lcw_treatment` WRITE;
/*!40000 ALTER TABLE `lcw_treatment` DISABLE KEYS */;
INSERT INTO `lcw_treatment` VALUES (13,29,'340826199806201052','2020-05-17 21:00:23','2,3','2,7',0,0,'感冒','喝热水'),(16,34,'340826199806201053','2020-05-20 22:49:57','2,3','2,7',0,0,'无','无');
/*!40000 ALTER TABLE `lcw_treatment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lcw_user`
--

DROP TABLE IF EXISTS `lcw_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lcw_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL COMMENT '用户名',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `phone` varchar(255) NOT NULL COMMENT '手机号码',
  `realname` varchar(255) NOT NULL COMMENT '真实姓名',
  `status` tinyint NOT NULL COMMENT '0:正常，1:禁止',
  `email` varchar(255) NOT NULL COMMENT '邮箱',
  `rolename` varchar(255) NOT NULL COMMENT '角色名',
  `roleid` int NOT NULL COMMENT '角色id',
  `fail_count` tinyint(1) NOT NULL COMMENT '登陆失败的次数',
  `fail_time` datetime DEFAULT NULL COMMENT '账号锁定的时间',
  `area` varchar(255) DEFAULT NULL COMMENT '县区',
  `city` varchar(255) DEFAULT NULL COMMENT '城市',
  `province` varchar(255) DEFAULT NULL COMMENT '省',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `sex` varchar(255) DEFAULT NULL COMMENT '性别',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lcw_user`
--

LOCK TABLES `lcw_user` WRITE;
/*!40000 ALTER TABLE `lcw_user` DISABLE KEYS */;
INSERT INTO `lcw_user` VALUES (1,'admin','e10adc3949ba59abbe56e057f20f883e','18955007261','王星宇',0,'1259754696@qq.com','管理员',1,0,NULL,'340826','340800_11_7','340000_17_11','蚌埠学院','保密');
/*!40000 ALTER TABLE `lcw_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-24 16:53:07
