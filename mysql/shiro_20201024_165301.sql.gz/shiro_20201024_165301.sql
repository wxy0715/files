-- MySQL dump 10.13  Distrib 8.0.20, for Linux (x86_64)
--
-- Host: localhost    Database: shiro
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sys_dept`
--

DROP TABLE IF EXISTS `sys_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dept` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `dept_no` text NOT NULL COMMENT '部门编号',
  `name` varchar(300) NOT NULL COMMENT '部门名称',
  `pid` varchar(64) NOT NULL COMMENT '父级id',
  `status` tinyint DEFAULT '1' COMMENT '状态(1:正常；0:弃用)',
  `relation_code` varchar(3000) DEFAULT NULL COMMENT '为了维护更深层级关系(规则：父级关系编码+自己的编码)',
  `dept_manager_id` varchar(64) DEFAULT NULL COMMENT '部门经理user_id',
  `manager_name` varchar(255) DEFAULT NULL COMMENT '部门经理名称',
  `phone` varchar(20) DEFAULT NULL COMMENT '部门经理联系电话',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` tinyint DEFAULT '1' COMMENT '是否删除(1未删除；0已删除)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dept`
--

LOCK TABLES `sys_dept` WRITE;
/*!40000 ALTER TABLE `sys_dept` DISABLE KEYS */;
INSERT INTO `sys_dept` VALUES ('09936ec4-cef1-44b0-be40-1d9adce44edd','dept-code-key_0000002','北京公司','fab724d7-be7c-48d0-b37a-d94edb56a4f1',1,'dept-code-key_0000001dept-code-key_0000002',NULL,'132','18955007261','2020-10-04 09:11:27','2020-10-04 11:05:10',1),('814d430a-7d78-4020-bcbc-6c259cae3d5a','dept-code-key_0000004','联合星桥总部','0',1,'dept-code-key_0000004',NULL,'威震天','','2020-10-07 10:54:49','2020-10-07 10:56:30',1),('b3a314d1-6358-4e51-888c-ecfb8c448aa4','dept-code-key_0000003','北京分公司','fab724d7-be7c-48d0-b37a-d94edb56a4f1',1,'dept-code-key_0000001dept-code-key_0000003',NULL,'da','11313','2020-10-04 09:11:52','2020-10-04 09:15:43',0),('fab724d7-be7c-48d0-b37a-d94edb56a4f1','dept-code-key_0000001','王星宇总部','0',1,'dept-code-key_0000001',NULL,'王星宇','18955007261','2020-09-27 19:32:47',NULL,1);
/*!40000 ALTER TABLE `sys_dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `id` varchar(64) NOT NULL COMMENT '文件存储主键id',
  `file_url` varchar(500) NOT NULL COMMENT '文件地址',
  `file_name` varchar(255) NOT NULL COMMENT '文件名称',
  `extension_name` varchar(255) NOT NULL COMMENT '文件扩展名',
  `original_name` varchar(255) NOT NULL COMMENT '原始文件名称',
  `type` tinyint NOT NULL DEFAULT '2' COMMENT '文件类型(1：其他类型文件；2:轮播图片；3：视频文件；)',
  `size` varchar(10) NOT NULL COMMENT '文件大小',
  `create_id` varchar(64) NOT NULL COMMENT '创建用户id',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件信息存储表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES ('58156af0-9edc-44b1-92d9-f2b0253da5f9','https://wxy-oss.oss-cn-beijing.aliyuncs.com/2020/10/15/852c528950d841ac9a5d7522d7fe16f3smallfb5eb76bfad671a169013c54fb79e5d51595173351.jpg','2020/10/15/852c528950d841ac9a5d7522d7fe16f3smallfb5eb76bfad671a169013c54fb79e5d51595173351.jpg','jpg','smallfb5eb76bfad671a169013c54fb79e5d51595173351.jpg',2,'97 KB','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','2020-10-15 17:31:05'),('6ccd43a0-bb63-4486-a228-9bcaa9c9b4c7','https://wxy-oss.oss-cn-beijing.aliyuncs.com/2020/10/15/d8356a9b9c214a16b38a04a6f0a2183920200415192716u=1337124397,3601513508&fm=26&gp=0.jpg','2020/10/15/d8356a9b9c214a16b38a04a6f0a2183920200415192716u=1337124397,3601513508&fm=26&gp=0.jpg','jpg','20200415192716u=1337124397,3601513508&fm=26&gp=0.jpg',2,'167 KB','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','2020-10-15 17:32:03'),('ecc0e5a8-9b02-479d-82b5-84da1c225dc5','https://wxy-oss.oss-cn-beijing.aliyuncs.com/2020/10/15/cbbb8fb9417846c5bbbd3a3b81028147smallfaa3728c8a225f771e19c586e9172ab41574854075.jpg','2020/10/15/cbbb8fb9417846c5bbbd3a3b81028147smallfaa3728c8a225f771e19c586e9172ab41574854075.jpg','jpg','smallfaa3728c8a225f771e19c586e9172ab41574854075.jpg',2,'163 KB','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','2020-10-15 17:31:32');
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `user_id` varchar(64) DEFAULT NULL COMMENT '用户id',
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `operation` varchar(50) DEFAULT NULL COMMENT '用户操作',
  `time` int DEFAULT NULL COMMENT '响应时间',
  `method` varchar(200) DEFAULT NULL COMMENT '请求方法',
  `params` varchar(5000) DEFAULT NULL COMMENT '请求参数',
  `ip` varchar(64) DEFAULT NULL COMMENT 'IP地址',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES ('0b2554c3-e725-4fe6-b1cb-7f5763fa06aa','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',86,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:43:26'),('12ca51d3-c1b6-4063-954e-12315327b483',NULL,NULL,'文件系统-轮播图管理-上传文件',2745,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:30:44'),('191e89a1-145c-41d7-8b2a-63ad8e914b16',NULL,NULL,'文件系统-轮播图管理-上传文件',1261,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:31:17'),('1b525aed-4d35-4792-9915-18b0ab14b72a','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',44,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:21:32'),('1c5ef6cb-1b89-4c24-abe0-30c674fa4346',NULL,NULL,'文件系统-文件管理-下载文件',17917,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:18:56'),('1ca3012a-d506-43d0-a46f-200b741931f4','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',2374,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:29:01'),('1cd8419e-6c88-4dcf-a6e4-a1f814388ad8',NULL,NULL,'文件系统-轮播图管理-上传文件',260,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:31:32'),('22f0b54b-45af-47e0-ab09-3e7395c583a6','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',1082,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:01:32'),('25a8b3e6-1aab-4f8f-a28e-5c1f4dac8fb2','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',73,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:20:19'),('29ce9933-71ac-47ba-84d9-908dbf2bee6c',NULL,NULL,'文件系统-轮播图管理-上传文件',301,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:01:21'),('2c964a9f-c991-4b96-910f-9f206a421ca5',NULL,NULL,'文件系统-轮播图管理-上传文件',1867,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:43:27'),('30318af2-a4e1-4d80-8a1a-f30c797c3f1d','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',70403,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:45:28'),('3202b594-0ebc-41ab-ac84-7faf62159a40','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',626,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:30:44'),('333b2f0c-d1a3-45a8-8329-a051573ef301',NULL,NULL,'文件系统-轮播图管理-上传文件',439,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:30:52'),('3355cfd1-7528-4193-b27e-59a3c5be53b1','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',78,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:30:35'),('3531db2a-d8a3-472d-b569-edcd04fdffd0',NULL,NULL,'文件系统-轮播图管理-上传文件',1434,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:35:44'),('37a1e1dc-54a7-434d-b67d-4213462e91b4','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',245,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:16:00'),('396819a2-113f-4114-afd0-59dfce3972e2','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',1630,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:43:05'),('3ab31edb-9809-4edb-83f5-eaa3f1998862','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',28960,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:15:36'),('4ba0caae-abe7-4b06-8011-0e13085b6b7f',NULL,NULL,'文件系统-轮播图管理-上传文件',301,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:21:11'),('50365eb0-8605-4218-8068-97ed2f5229da',NULL,NULL,'文件系统-轮播图管理-上传文件',1918,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:32:04'),('548a216b-570a-459a-b5cb-afdcfd945e09',NULL,NULL,'文件系统-轮播图管理-上传文件',225,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:45:52'),('57da69d9-4ec9-4faa-bea2-c94cd621c8a2','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-新增轮播图',642,'com.wxy.demo.controller.RotationChartController.addRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:31:10'),('585c2019-26f4-4153-834a-c56a14489cc4','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','组织管理-角色管理-分页获取角色数据接口',119,'com.wxy.demo.controller.RoleController.pageInfo()','[{\"pageNum\":1,\"pageSize\":10}]','0:0:0:0:0:0:0:1','2020-10-15 16:54:36'),('58d60a69-f204-4e70-b364-af6c9ec2d44c',NULL,NULL,'文件系统-轮播图管理-上传文件',635,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:15:06'),('5b09720a-1f8e-49ff-b384-1d62bc97b4e5','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','系统管理-日志管理-删除日志接口',83,'com.wxy.demo.controller.LogController.deletedLog()','[[\"f34918cf-8acb-4dab-8b71-dcbbce76293e\"]]','0:0:0:0:0:0:0:1','2020-10-15 15:34:42'),('5d27b91c-601b-4d6e-af15-0a99c8adde6d','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','组织管理-部门管理-部门树形结构列表接口',39,'com.wxy.demo.controller.DeptController.getDeptTree()','[null]','36.61.185.1','2020-10-18 15:28:03'),('5f9a5b85-ec06-4f81-8ca1-93fcb8e052cb','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',605,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:59:30'),('5fca9790-18ef-47d8-b4c1-bfa47d7fdc26','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','组织管理-菜单权限管理-获取所有的菜单权限数据接口',1947,'com.wxy.demo.controller.PermissionController.getAllPermission()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 15:33:01'),('617b405e-6ca7-4d5a-a116-ebec89f1f739','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','组织管理-部门管理-查询所有部门数据接口',85,'com.wxy.demo.controller.DeptController.getAllDept()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 15:33:18'),('62b5cf52-e0cb-4a26-9dfc-ecd3ab6ad073','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-新增轮播图',69,'com.wxy.demo.controller.RotationChartController.addRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:01:24'),('62f7b1ac-0adb-4ad9-bdc1-8b661d187584','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',1440,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:04:47'),('63170b8c-7921-4575-99c5-96230cfd5b17','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',44,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:35:44'),('65064d0c-02f0-4f2a-921e-cbb6775d4eb9','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',2279,'com.wxy.demo.controller.FileController.download()',NULL,'60.170.26.35','2020-10-15 19:21:21'),('679e7319-1ca3-4cb5-9b33-24a0d117f91e','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-新增轮播图',26,'com.wxy.demo.controller.RotationChartController.addRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:31:32'),('69f98f2a-9492-46de-8509-fe20767fc843','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',73248,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:59:34'),('6a1eb1dc-5030-4760-b2f6-c442e6a180b3',NULL,NULL,'文件系统-轮播图管理-上传文件',653,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:18:01'),('6c10ce1c-f0d6-4de4-94fe-acae97cefe25',NULL,NULL,'文件系统-轮播图管理-上传文件',485,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:02:10'),('6c54e640-281e-4977-b128-515fb07b84e3','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',345,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:43:35'),('6fce596d-b924-4ff1-873f-f2ba81c3fe2c',NULL,NULL,'文件系统-轮播图管理-上传文件',591,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:59:42'),('7934e0c4-68d2-4877-801c-ea7f59d7408d','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-新增轮播图',26,'com.wxy.demo.controller.RotationChartController.addRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:21:23'),('799e73f2-4110-4537-a103-54fddb1a4d08','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',436,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:01:12'),('7e3e2961-3cf7-4a61-80ff-414155bacc6a','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','组织管理-角色管理-分页获取角色数据接口',44,'com.wxy.demo.controller.RoleController.pageInfo()','[{\"pageNum\":1,\"pageSize\":10}]','0:0:0:0:0:0:0:1','2020-10-15 15:33:08'),('84471ee0-1fb5-416c-9d60-825370e7d77d','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-新增轮播图',31,'com.wxy.demo.controller.RotationChartController.addRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:18:28'),('86fd07d3-239b-46b2-a588-56bb6019bb28',NULL,NULL,'文件系统-轮播图管理-上传文件',265,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:00:07'),('873c7930-2d56-4cbe-880d-5a29e4fc8b03','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','组织管理-角色管理-获取角色详情接口',1947,'com.wxy.demo.controller.RoleController.detailInfo()','[\"b125dbb8-459e-409f-bd1f-d17966568eda\"]','0:0:0:0:0:0:0:1','2020-10-15 15:33:13'),('924fe899-ea75-48be-a6a1-d446b3385ab3','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',47490,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:32:42'),('97ee8e3b-8472-480e-a35f-87462d0c1a5e','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',385,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:30:08'),('9877989d-5066-472e-b4e3-33175ff374e9','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',38,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:31:17'),('9f4e0842-e493-4686-ac24-d011238b59a1','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-新增轮播图',1209,'com.wxy.demo.controller.RotationChartController.addRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:32:09'),('a156904c-0365-4bf2-9f7b-dd7b37acda8d','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-删除轮播图',168,'com.wxy.demo.controller.RotationChartController.deleteRotation()','[[{\"fileUrl\":\"https://wxy-oss.oss-cn-beijing.aliyuncs.com/2020/10/15/856571fc49e44ed5b1cb1d84ac5ed38esmallfaa3728c8a225f771e19c586e9172ab41574854075.jpg\",\"id\":\"75e31e10-5916-4879-8135-75a3ddf61a0f\"}]]','0:0:0:0:0:0:0:1','2020-10-15 16:20:24'),('a1661f61-67c5-4738-a014-7c66f611c8ea','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',1640,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:21:12'),('a58e6ede-d20c-429e-8542-654158d9e1a8',NULL,NULL,'文件系统-轮播图管理-上传文件',686,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:31:05'),('a621155a-7f54-43bc-83f4-0129864a3961','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',818,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:45:56'),('aa52c466-7887-4c7d-a2a3-30e7f253bf07',NULL,NULL,'文件系统-轮播图管理-上传文件',222,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:15:59'),('aca902c1-7d70-4610-b137-e63913d5d297','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',46,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:17:51'),('acd03fb9-080a-4b3f-97f6-ed43464a1c2c',NULL,NULL,'文件系统-轮播图管理-上传文件',576,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:21:23'),('ad39ea3e-8533-4f51-a37f-e8e62132c367',NULL,NULL,'文件系统-文件管理-下载文件',5785,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:33:12'),('b0b13266-dbc5-4982-a7cc-11681d8f67ad','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',43,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:16:43'),('ba058d5f-3a74-401d-a9ce-db1c004daf56','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',66,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:59:19'),('bd6d0b2d-73a9-4d71-8de3-d01491b3b1cb','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',43,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:22:33'),('bf2bfa4a-bca5-4724-822c-9a0d92bb1a5a',NULL,NULL,'文件系统-轮播图管理-上传文件',1221,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:17:13'),('c130714a-2719-4001-9701-5f99af301676',NULL,NULL,'文件系统-轮播图管理-上传文件',48760,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:32:42'),('c4f1160f-2e98-4ea2-b727-b88613526784',NULL,NULL,'文件系统-轮播图管理-上传文件',469,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:36:08'),('ca9d8f44-f4c5-4ecf-8f55-03af5ba7e532','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',277,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:31:02'),('cb91b54e-33ad-43d0-a10b-09598ea09308','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','组织管理-菜单权限管理-获取所有的菜单权限数据接口',2082,'com.wxy.demo.controller.PermissionController.getAllPermission()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 15:33:35'),('ceab9c38-1aaa-4abf-a270-a13a474096d2','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',188,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:01:49'),('d2ee65d2-9be9-47de-b4c7-f31406e6b676',NULL,NULL,'文件系统-轮播图管理-上传文件',1034,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:43:03'),('d5a8f95b-f6ce-4733-809c-2199e7bb453b','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',202,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:01:05'),('d7bd1ae0-7faa-4076-acba-ee9abeeb0fe0','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','组织管理-角色管理-分页获取角色数据接口',182,'com.wxy.demo.controller.RoleController.pageInfo()','[{\"pageNum\":1,\"pageSize\":10}]','60.170.26.35','2020-10-15 19:20:56'),('d9ce5bd3-fade-4e23-8a18-81e3b878284e',NULL,NULL,'文件系统-轮播图管理-上传文件',1022,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:43:34'),('e368eff8-c872-4b35-88d5-c6a6f9d025b1','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',659,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:00:01'),('e4b1fb8f-65bd-4bac-9996-f02dc211247e','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',51670,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:22:54'),('eb853ed5-565e-4551-b7bf-589e7dab7020','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-轮播图管理-轮播图后端编辑',61,'com.wxy.demo.controller.RotationChartController.updateRotation()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:17:13'),('ec1ab312-0402-4976-ab3f-28111a1729cc',NULL,NULL,'文件系统-轮播图管理-上传文件',1627,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:01:48'),('ec8ec9ab-1d65-4b19-8a82-acf914ecb390',NULL,NULL,'文件系统-轮播图管理-上传文件',2974,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:59:31'),('f13ff217-a05f-472c-9ba4-837457ff33a3',NULL,NULL,'文件系统-轮播图管理-上传文件',410,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:34:32'),('f1923062-dadf-45ee-ae21-b0873febc562',NULL,NULL,'文件系统-文件管理-下载文件',3354,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 17:32:55'),('f29491c6-b4d5-4d40-b995-1cbe141cd21e',NULL,NULL,'文件系统-轮播图管理-上传文件',809,'com.wxy.demo.controller.FileController.upload()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:44:14'),('f7ec9023-5772-432b-9d55-160b10c74d0f','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',1191,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:30:06'),('fe3efa02-e83f-436d-b99a-220e1e922e00','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','组织管理-菜单权限管理-获取所有的菜单权限数据接口',767,'com.wxy.demo.controller.PermissionController.getAllPermission()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 16:54:38'),('fe91f027-ae02-4c0a-81d9-b18a7f1f3a74','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','文件系统-文件管理-下载文件',343,'com.wxy.demo.controller.FileController.download()',NULL,'0:0:0:0:0:0:0:1','2020-10-15 18:21:27');
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_permission`
--

DROP TABLE IF EXISTS `sys_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_permission` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `code` varchar(64) DEFAULT NULL COMMENT '菜单权限编码',
  `name` varchar(300) DEFAULT NULL COMMENT '菜单权限名称',
  `perms` varchar(500) DEFAULT NULL COMMENT '授权(如：sys:user:add)',
  `url` varchar(100) DEFAULT NULL COMMENT '访问地址URL',
  `method` varchar(10) DEFAULT NULL COMMENT '资源请求类型',
  `pid` varchar(64) DEFAULT NULL COMMENT '父级菜单权限名称',
  `order_num` int DEFAULT '0' COMMENT '排序',
  `type` tinyint DEFAULT NULL COMMENT '菜单权限类型(1:目录;2:菜单;3:按钮)',
  `status` tinyint DEFAULT '1' COMMENT '状态1:正常 0：禁用',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` tinyint DEFAULT '1' COMMENT '是否删除(1未删除；0已删除)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_permission`
--

LOCK TABLES `sys_permission` WRITE;
/*!40000 ALTER TABLE `sys_permission` DISABLE KEYS */;
INSERT INTO `sys_permission` VALUES ('013095aa-0f4d-4c32-b30e-229a587e52ad','btn-dept-add','新增部门权限','sys:dept:add','/api/dept','POST','8f393e44-b585-4875-866d-71f88fea9659',100,3,1,'2020-01-08 15:44:18',NULL,1),('03dc1cbf-ef44-4326-a7dc-10fe16d22dad','btn-log-list','查询日志列表权限','sys:log:list','/api/logs','POST','0545d9d1-c82c-44c2-85e5-0b6ac4042515',100,3,1,'2020-01-08 16:12:14',NULL,1),('0545d9d1-c82c-44c2-85e5-0b6ac4042515','','日志管理','','/index/logs','','4caeb861-354c-45f6-98b4-59f486beb511',100,2,1,'2020-01-08 13:57:12',NULL,1),('075224a7-1805-4f2f-a325-157effaf0004','btn-rotation-delete','删除轮播图权限','sys:rotation:delete','/api/rotation','DELETE','c095273c-7917-4503-8569-6a67a9979d56',100,3,1,'2020-04-02 08:02:57',NULL,1),('145cb90b-d205-40f6-8a2d-703f41ed1feb','btn-user-delete','删除用户权限','sys:user:delete','/api/user','DELETE','9ce621a0-ee2c-4cf6-b7bd-012a1a01ba63',100,3,1,'2020-01-08 15:42:50',NULL,1),('15bb6aff-2e3b-490a-a21f-0167ae0ebc0d','btn-log-delete','删除日志权限','sys:log:delete','/api/log','DELETE','0545d9d1-c82c-44c2-85e5-0b6ac4042515',100,3,1,'2020-01-08 16:12:53',NULL,1),('2446fd0d-11ba-44aa-9128-531e38ec3b7a','','轮播图前端展现','','/index/rotation/show','GET','ccef525e-3392-45f8-969f-d552b142dc0f',100,2,1,'2020-04-03 07:27:47',NULL,1),('24b7b13c-f00f-4e6b-a221-fe2d780e4d4f','','接口管理','','/swagger-ui.html','GET','4caeb861-354c-45f6-98b4-59f486beb511',97,2,1,'2020-01-08 14:28:56',NULL,1),('26694831-fc81-4590-9095-af7e55b9819a','btn-rotation-list','轮播图列表查询权限','sys:rotation:list','/api/rotations','POST','c095273c-7917-4503-8569-6a67a9979d56',100,3,1,'2020-04-01 08:21:41',NULL,1),('27acf73b-2fcb-451b-bdc4-e11e5ab41e2a','btn-dept-delete','删除部门权限','sys:dept:delete','/api/dept/*','DELETE','8f393e44-b585-4875-866d-71f88fea9659',100,3,1,'2020-01-08 15:45:52',NULL,1),('290c0240-0914-487c-b4e9-6635bf5ebfec','','菜单权限管理','','/index/menus','GET','346df872-8964-4455-8afd-ffa6308fb18a',99,2,1,'2020-01-06 21:55:59','2020-01-08 09:10:59',1),('2ae13993-9501-46d5-8473-fe45fee57f3b','btn-user-add','新增用户权限','sys:user:add','/api/user','POST','9ce621a0-ee2c-4cf6-b7bd-012a1a01ba63',100,3,1,'2020-01-08 15:40:36',NULL,1),('2eeaa020-74d5-4c4b-9849-2cf4bd68fed9','btn-role-update','更新角色权限','sys:role:update','/api/role','PUT','c198d1cb-ad4d-4001-9375-9ec8ee04053d',100,3,1,'2020-01-08 16:09:55',NULL,1),('2f9a3f67-6ef3-4eac-b9a1-c0e898718d0c','btn-permission-delete','删除菜单权限','sys:permission:delete','/api/permission','DELETE','290c0240-0914-487c-b4e9-6635bf5ebfec',100,3,1,'2020-01-08 15:48:37',NULL,1),('346df872-8964-4455-8afd-ffa6308fb18a','','组织管理','','','','0',100,1,1,'2020-01-06 21:53:55',NULL,1),('38fe5e2b-9943-4e42-a085-5df352103dda','','运维报表','','/view','','0',11,1,1,'2020-09-21 21:14:39','2020-10-15 15:31:27',0),('390ded0e-9f48-40a7-a841-791c203f22ae','btn-permission-list','查询菜单权限列表权限','sys:permission:list','/api/permissions','POST','290c0240-0914-487c-b4e9-6635bf5ebfec',100,3,1,'2020-01-08 15:46:36',NULL,1),('39313e6a-14ed-4224-a91e-ef6a10ba54cd','btn-dept-list','查询部门信息列表权限','sys:dept:list','/api/depts','POST','8f393e44-b585-4875-866d-71f88fea9659',100,3,1,'2020-01-08 15:43:36',NULL,1),('41412d6d-d86a-4cfd-9aa7-d51f9ced0dfe','','测试删除','','','','346df872-8964-4455-8afd-ffa6308fb18a',100,1,1,'2020-01-08 09:30:53','2020-01-08 09:31:01',0),('47697e92-e199-4420-a2c2-09ec1b08cb9d','btn-user-list','查询用户信息列表权限','sys:user:list','/api/users','POST','9ce621a0-ee2c-4cf6-b7bd-012a1a01ba63',100,3,1,'2020-01-08 15:39:55',NULL,1),('4caeb861-354c-45f6-98b4-59f486beb511','','系统管理','','','','0',98,1,1,'2020-01-08 13:55:56',NULL,1),('5695ed19-5620-4da4-8cb0-159f34ae6591','btn-rotation-update','编辑轮播图权限','sys:rotation:update','/api/rotation','PUT','c095273c-7917-4503-8569-6a67a9979d56',100,3,1,'2020-04-02 07:34:09',NULL,1),('65734896-90c5-4b48-b9e8-dee47a74a297','btn-role-delete','删除角色权限','sys:role:delete','/api/role/*','DELETE','c198d1cb-ad4d-4001-9375-9ec8ee04053d',100,3,1,'2020-01-08 16:11:22','2020-10-09 21:53:53',1),('7141c2e9-6d50-46b6-94e8-100466b7249f','','SQL监控','','/druid/sql.html','GET','4caeb861-354c-45f6-98b4-59f486beb511',96,2,1,'2020-01-08 14:30:01',NULL,1),('8180e320-e2bf-470c-bb42-80fb5bf9f5c3','','我的文件','','/index/files','GET','f1ea1abb-3dde-4196-b054-2ae2fcfe7c23',100,2,1,'2020-04-06 07:16:13',NULL,1),('84b9b525-aa44-4b16-9900-adca26115a37','btn-role-add','新增角色权限','sys:role:add','/api/role','POST','c198d1cb-ad4d-4001-9375-9ec8ee04053d',100,3,1,'2020-01-08 15:50:00',NULL,1),('8f393e44-b585-4875-866d-71f88fea9659','','部门管理','','/index/depts','','346df872-8964-4455-8afd-ffa6308fb18a',97,2,1,'2020-01-07 18:28:31',NULL,1),('90b3be91-5e9d-42f8-81fb-0c9ef3014faa','btn-role-detail','角色详情权限','sys:role:detail','/api/role/*','GET','c198d1cb-ad4d-4001-9375-9ec8ee04053d',100,3,1,'2020-01-08 16:10:32',NULL,1),('94fe50a9-f5af-4f3c-84e4-18b3a84d7a58','btn-rotation-add','新增轮播图权限','sys:rotation:add','/api/rotation','POST','c095273c-7917-4503-8569-6a67a9979d56',10,3,1,'2020-04-01 08:32:59',NULL,1),('9ce621a0-ee2c-4cf6-b7bd-012a1a01ba63','','用户管理','','/index/users','','346df872-8964-4455-8afd-ffa6308fb18a',96,2,1,'2020-01-07 19:49:37','2020-01-08 10:01:38',1),('b7348d63-c4d3-406d-9e46-543346674275','btn-dept-update','更新部门信息权限','sys:dept:update','/api/dept','PUT','8f393e44-b585-4875-866d-71f88fea9659',100,3,1,'2020-01-08 15:44:59',NULL,1),('bb5ca869-0303-4fc0-b067-936cba7d1cc8','btn-permission-update','更新菜单权限','sys:permission:update','/api/permission','PUT','290c0240-0914-487c-b4e9-6635bf5ebfec',100,3,1,'2020-01-08 15:47:56',NULL,1),('c095273c-7917-4503-8569-6a67a9979d56','','轮播图管理','','/index/rotations','GET','f1ea1abb-3dde-4196-b054-2ae2fcfe7c23',100,2,1,'2020-04-01 08:20:55',NULL,1),('c198d1cb-ad4d-4001-9375-9ec8ee04053d','','角色管理','','/index/roles','','346df872-8964-4455-8afd-ffa6308fb18a',100,2,1,'2020-01-06 22:33:55','2020-01-08 09:13:30',1),('ccef525e-3392-45f8-969f-d552b142dc0f','','前端页面展示','','','','0',100,1,1,'2020-04-03 07:27:11',NULL,1),('d41c2bc3-454c-4f62-84fe-97825d5cf8a7','btn-user-update-role','赋予用户角色权限','sys:user:role:update','/api/user/roles','PUT','9ce621a0-ee2c-4cf6-b7bd-012a1a01ba63',100,3,1,'2020-01-08 15:41:20',NULL,1),('d60faf3e-9a72-49d5-b02d-a67bfeff07fa','btn-user-update','列表更新用户信息权限','sys:user:update','/api/user','PUT','9ce621a0-ee2c-4cf6-b7bd-012a1a01ba63',100,3,1,'2020-01-08 15:42:06',NULL,1),('de8e2328-4313-477e-9644-3ca93799cc76','btn-role-add','角色管理-新增角色','sys:role:add','/api/role','POST','c198d1cb-ad4d-4001-9375-9ec8ee04053d',100,3,1,'2020-01-08 15:28:09','2020-01-08 15:29:31',0),('e136cc74-9817-4ef1-b181-8f1afd7e102c','btn-permission-add','新增菜单权限','sys:permission:add','/api/permission','POST','290c0240-0914-487c-b4e9-6635bf5ebfec',100,3,1,'2020-01-08 15:47:16',NULL,1),('f1ea1abb-3dde-4196-b054-2ae2fcfe7c23','','文件系统','','','','0',90,1,1,'2020-04-01 08:20:26',NULL,1),('f9f4d9f4-a2f5-430c-9f2d-6c8e650a8c39','btn-role-list','查询角色列表权限','sys:role:list','/api/roles','POST','c198d1cb-ad4d-4001-9375-9ec8ee04053d',100,3,1,'2020-01-08 15:49:20',NULL,1);
/*!40000 ALTER TABLE `sys_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `name` varchar(255) DEFAULT NULL COMMENT '角色名称',
  `description` varchar(300) DEFAULT NULL,
  `status` tinyint DEFAULT '1' COMMENT '状态(1:正常0:弃用)',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` tinyint DEFAULT '1' COMMENT '是否删除(1未删除；0已删除)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES ('333aca1b-a87a-4ca6-a7e7-be4250689d6d','测试删除角色','测试删除角色',1,'2020-01-08 10:49:49','2020-01-08 10:53:00',0),('354cc78b-e3c5-43d4-98d6-5098c3635c3c','测试角色删除','测试角色删除',1,'2020-01-08 10:46:10','2020-01-08 10:46:15',0),('37515078-f53c-4dbf-9c9f-a44ec7635159','wxy','wxy',1,'2020-09-25 09:36:42',NULL,1),('5e82fad6-3f27-482d-8bc1-56767e83631b','标记用户角色测试','标记用户角色测试',1,'2020-01-08 10:48:13','2020-01-08 10:49:46',0),('7fc21a58-20a3-4ed0-ac74-e5eceb4809c3','测试角色','测试角色',1,'2020-01-08 10:45:31','2020-01-08 10:47:28',0),('a6b18d32-2ad9-4547-9314-665a2bb55ff4','角色回显测试5','角色回显测试5',1,'2020-01-08 10:03:23','2020-01-08 12:00:46',0),('aa5a4ba3-257b-4537-aec3-dd727c18fb9b','测试是否会自定刷新token角色','测试是否会自定刷新token角色',1,'2020-01-08 10:46:55','2020-01-08 10:52:13',0),('aafc73b8-37af-4dc0-aa3e-cf1f6f9a954a','测试角色删除功能','测试角色删除功能',1,'2020-01-08 10:53:38','2020-01-08 11:02:40',0),('b125dbb8-459e-409f-bd1f-d17966568eda','超级管理员','我是超级管理员',1,'2020-01-06 23:37:45','2020-10-12 21:33:59',1),('c0f54870-8703-4242-995f-73bbc71a18f5','标记用户角色测试','标记用户角色测试',1,'2020-01-08 10:53:35','2020-01-08 11:06:36',0),('cb9f4b37-4924-42db-b569-f5c448b4b971','测试删除角色','432432',1,'2020-01-08 10:54:24','2020-01-08 10:45:12',0),('e14e2c33-a45d-49bc-9502-a9bb89b587be','组织','组织',1,'2020-10-04 09:10:16','2020-10-08 16:38:09',1),('fc674bde-29ee-4160-bd97-00761357f019','test','我是test',1,'2020-01-07 21:19:04','2020-10-04 09:10:42',0);
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_permission`
--

DROP TABLE IF EXISTS `sys_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_permission` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `role_id` varchar(64) DEFAULT NULL COMMENT '角色id',
  `permission_id` varchar(64) DEFAULT NULL COMMENT '菜单权限id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_permission`
--

LOCK TABLES `sys_role_permission` WRITE;
/*!40000 ALTER TABLE `sys_role_permission` DISABLE KEYS */;
INSERT INTO `sys_role_permission` VALUES ('02eaebbd-feb2-4222-9a1c-2620f3e58445','b125dbb8-459e-409f-bd1f-d17966568eda','84b9b525-aa44-4b16-9900-adca26115a37','2020-10-12 21:33:59'),('0759778a-2034-44d7-ab98-16f7edfa8e1b','b125dbb8-459e-409f-bd1f-d17966568eda','e136cc74-9817-4ef1-b181-8f1afd7e102c','2020-10-12 21:33:59'),('08aca638-3545-423e-ba45-abe523864797','b125dbb8-459e-409f-bd1f-d17966568eda','013095aa-0f4d-4c32-b30e-229a587e52ad','2020-04-06 07:16:20'),('0981b8ba-90aa-4f54-90ee-fb46ff49945a','b125dbb8-459e-409f-bd1f-d17966568eda','290c0240-0914-487c-b4e9-6635bf5ebfec','2020-10-12 21:33:59'),('0af79f7f-9e24-4d2d-a810-e6dbe626155b','e14e2c33-a45d-49bc-9502-a9bb89b587be','8f393e44-b585-4875-866d-71f88fea9659','2020-10-04 09:10:16'),('0b1b8f90-7aa0-4aa3-a8c2-7aef5f9dbebb','37515078-f53c-4dbf-9c9f-a44ec7635159','b7348d63-c4d3-406d-9e46-543346674275','2020-09-25 09:36:54'),('0d95fea2-2f25-4563-bab4-7b6c57d9a516','b125dbb8-459e-409f-bd1f-d17966568eda','8180e320-e2bf-470c-bb42-80fb5bf9f5c3','2020-04-06 07:16:20'),('0dc5ca09-f80a-4ad1-b3cd-d5b3eb5964a1','e14e2c33-a45d-49bc-9502-a9bb89b587be','290c0240-0914-487c-b4e9-6635bf5ebfec','2020-10-04 09:10:32'),('0f7600f4-dde2-4c5a-a98b-c3a391c6a4db','37515078-f53c-4dbf-9c9f-a44ec7635159','39313e6a-14ed-4224-a91e-ef6a10ba54cd','2020-09-25 09:36:54'),('0fc52445-b477-4756-b290-84b787dc89a4','b125dbb8-459e-409f-bd1f-d17966568eda','c198d1cb-ad4d-4001-9375-9ec8ee04053d','2020-04-06 07:16:20'),('107d323f-62fd-425e-9f1d-2604098db99c','b125dbb8-459e-409f-bd1f-d17966568eda','013095aa-0f4d-4c32-b30e-229a587e52ad','2020-10-12 21:33:59'),('13485e0d-2d15-4467-a35d-bec60f988eab','b125dbb8-459e-409f-bd1f-d17966568eda','075224a7-1805-4f2f-a325-157effaf0004','2020-10-12 21:33:59'),('13e1dc4c-940e-4e3d-b2a5-a4d0d7e4cdc8','e14e2c33-a45d-49bc-9502-a9bb89b587be','013095aa-0f4d-4c32-b30e-229a587e52ad','2020-10-04 09:10:32'),('18d5f9bd-add9-47c5-bbad-da738ea8708b','b125dbb8-459e-409f-bd1f-d17966568eda','5695ed19-5620-4da4-8cb0-159f34ae6591','2020-10-12 21:33:59'),('1d6a0ec7-c9f0-4f9b-8ada-5072293f9a59','b125dbb8-459e-409f-bd1f-d17966568eda','2f9a3f67-6ef3-4eac-b9a1-c0e898718d0c','2020-10-12 21:33:59'),('1f541f11-1637-4698-8899-28fc551f5da2','b125dbb8-459e-409f-bd1f-d17966568eda','65734896-90c5-4b48-b9e8-dee47a74a297','2020-10-12 21:33:59'),('20df95fb-4f7e-4f83-8b41-1472685c4e53','b125dbb8-459e-409f-bd1f-d17966568eda','c095273c-7917-4503-8569-6a67a9979d56','2020-04-06 07:16:20'),('26a1d635-d562-4c06-bee4-97158d932f88','b125dbb8-459e-409f-bd1f-d17966568eda','2ae13993-9501-46d5-8473-fe45fee57f3b','2020-10-12 21:33:59'),('27307b74-0600-4686-bbe6-bba4dc971e64','37515078-f53c-4dbf-9c9f-a44ec7635159','2ae13993-9501-46d5-8473-fe45fee57f3b','2020-09-25 09:36:54'),('3772aff3-27f5-450c-b355-d73887934654','b125dbb8-459e-409f-bd1f-d17966568eda','145cb90b-d205-40f6-8a2d-703f41ed1feb','2020-04-06 07:16:20'),('382dc8b9-f484-4cea-be7e-8b8be4e2dba0','e14e2c33-a45d-49bc-9502-a9bb89b587be','8f393e44-b585-4875-866d-71f88fea9659','2020-10-04 09:10:32'),('398b4fa3-67cc-4882-814f-54528cf4eb34','b125dbb8-459e-409f-bd1f-d17966568eda','b7348d63-c4d3-406d-9e46-543346674275','2020-10-12 21:33:59'),('3d8dea02-227b-4f6c-a4f4-086174ccf086','b125dbb8-459e-409f-bd1f-d17966568eda','94fe50a9-f5af-4f3c-84e4-18b3a84d7a58','2020-04-06 07:16:20'),('3f98ca20-3d59-49b4-812a-e8435ff55f90','b125dbb8-459e-409f-bd1f-d17966568eda','7141c2e9-6d50-46b6-94e8-100466b7249f','2020-04-06 07:16:20'),('3fd4b3c3-77ce-43b6-8a31-eaacf9b8ab7f','e14e2c33-a45d-49bc-9502-a9bb89b587be','2446fd0d-11ba-44aa-9128-531e38ec3b7a','2020-10-04 09:10:32'),('45009672-eac1-4389-b09e-7bbced305901','b125dbb8-459e-409f-bd1f-d17966568eda','346df872-8964-4455-8afd-ffa6308fb18a','2020-10-12 21:33:59'),('4931db0d-b316-430f-b7a8-0d823ffb6539','e14e2c33-a45d-49bc-9502-a9bb89b587be','ccef525e-3392-45f8-969f-d552b142dc0f','2020-10-08 16:38:09'),('4b87de05-886b-4817-ba52-e23756d884db','37515078-f53c-4dbf-9c9f-a44ec7635159','47697e92-e199-4420-a2c2-09ec1b08cb9d','2020-09-25 09:36:54'),('4bc85186-8d2a-4417-a337-a46f7c0d8d53','b125dbb8-459e-409f-bd1f-d17966568eda','0545d9d1-c82c-44c2-85e5-0b6ac4042515','2020-04-06 07:16:20'),('4c404bf5-cec7-4ccc-b5ef-0083a2661c2b','b125dbb8-459e-409f-bd1f-d17966568eda','e136cc74-9817-4ef1-b181-8f1afd7e102c','2020-04-06 07:16:20'),('4dd95fef-a844-4578-95b5-47b3a8310d02','b125dbb8-459e-409f-bd1f-d17966568eda','bb5ca869-0303-4fc0-b067-936cba7d1cc8','2020-04-06 07:16:20'),('4f8e6bfd-13f1-4812-bcf0-35c3c63479d1','b125dbb8-459e-409f-bd1f-d17966568eda','ccef525e-3392-45f8-969f-d552b142dc0f','2020-04-06 07:16:20'),('4f99d99d-5101-408c-b72a-90036a1818ee','e14e2c33-a45d-49bc-9502-a9bb89b587be','c198d1cb-ad4d-4001-9375-9ec8ee04053d','2020-10-08 16:38:09'),('50d8392a-6e5b-4c84-8d11-304bbb08ce62','b125dbb8-459e-409f-bd1f-d17966568eda','4caeb861-354c-45f6-98b4-59f486beb511','2020-10-12 21:33:59'),('5188d1fa-e348-48c8-a8bb-327cf2c3c023','e14e2c33-a45d-49bc-9502-a9bb89b587be','2eeaa020-74d5-4c4b-9849-2cf4bd68fed9','2020-10-04 09:10:16'),('531bd1a1-b930-4495-8464-f7d2c1c7dbca','b125dbb8-459e-409f-bd1f-d17966568eda','2f9a3f67-6ef3-4eac-b9a1-c0e898718d0c','2020-04-06 07:16:20'),('5397ee67-c5a8-42e1-871c-492875eb3937','b125dbb8-459e-409f-bd1f-d17966568eda','84b9b525-aa44-4b16-9900-adca26115a37','2020-04-06 07:16:20'),('5407096f-5127-44f7-a7d2-72166a2a0426','e14e2c33-a45d-49bc-9502-a9bb89b587be','8f393e44-b585-4875-866d-71f88fea9659','2020-10-08 16:38:09'),('571b0989-4c04-4b96-8f69-5e920aed9804','b125dbb8-459e-409f-bd1f-d17966568eda','94fe50a9-f5af-4f3c-84e4-18b3a84d7a58','2020-10-12 21:33:59'),('585d1d48-4163-4b9b-b2ae-9f428a6448e3','b125dbb8-459e-409f-bd1f-d17966568eda','f9f4d9f4-a2f5-430c-9f2d-6c8e650a8c39','2020-10-12 21:33:59'),('5b435bcf-9f74-4b51-87dc-fe63ae7c1267','e14e2c33-a45d-49bc-9502-a9bb89b587be','2eeaa020-74d5-4c4b-9849-2cf4bd68fed9','2020-10-08 16:38:09'),('5f7c330a-af4d-48a3-93b5-699ff20444b2','b125dbb8-459e-409f-bd1f-d17966568eda','39313e6a-14ed-4224-a91e-ef6a10ba54cd','2020-10-12 21:33:59'),('60cb3963-ec0b-4429-8df4-6ac17f2d5d0e','b125dbb8-459e-409f-bd1f-d17966568eda','26694831-fc81-4590-9095-af7e55b9819a','2020-10-12 21:33:59'),('64cbf7d6-1795-4bc2-87e9-545be89cb983','b125dbb8-459e-409f-bd1f-d17966568eda','2eeaa020-74d5-4c4b-9849-2cf4bd68fed9','2020-04-06 07:16:20'),('6768b29e-4a71-45a0-9363-370ff545b41b','37515078-f53c-4dbf-9c9f-a44ec7635159','346df872-8964-4455-8afd-ffa6308fb18a','2020-09-25 09:36:54'),('6ac0df56-0c91-4002-8e15-98124b41323d','37515078-f53c-4dbf-9c9f-a44ec7635159','8f393e44-b585-4875-866d-71f88fea9659','2020-09-25 09:36:54'),('6dcb794a-6ff8-4b4a-b6cc-3a3db4e1c490','e14e2c33-a45d-49bc-9502-a9bb89b587be','ccef525e-3392-45f8-969f-d552b142dc0f','2020-10-04 09:10:32'),('6fb17c51-1aa8-4107-8d00-66d4a3064b74','b125dbb8-459e-409f-bd1f-d17966568eda','03dc1cbf-ef44-4326-a7dc-10fe16d22dad','2020-10-12 21:33:59'),('752da4f5-24e1-4bea-8931-48127bee25ae','37515078-f53c-4dbf-9c9f-a44ec7635159','e136cc74-9817-4ef1-b181-8f1afd7e102c','2020-09-25 09:36:54'),('795e78dc-8c08-4d3b-9c2b-0e28df41c452','b125dbb8-459e-409f-bd1f-d17966568eda','2446fd0d-11ba-44aa-9128-531e38ec3b7a','2020-10-12 21:33:59'),('7ae8fd58-41b7-45ce-82fd-81068f4029cb','b125dbb8-459e-409f-bd1f-d17966568eda','ccef525e-3392-45f8-969f-d552b142dc0f','2020-10-12 21:33:59'),('7ce35cbf-2bd0-4cd7-8b27-189461906df9','b125dbb8-459e-409f-bd1f-d17966568eda','24b7b13c-f00f-4e6b-a221-fe2d780e4d4f','2020-10-12 21:33:59'),('7deda88a-8eaf-4ad5-a7bb-d8e6b59ffe2f','b125dbb8-459e-409f-bd1f-d17966568eda','39313e6a-14ed-4224-a91e-ef6a10ba54cd','2020-04-06 07:16:20'),('8548cb40-3fbc-4676-8114-a13b865fd057','e14e2c33-a45d-49bc-9502-a9bb89b587be','c198d1cb-ad4d-4001-9375-9ec8ee04053d','2020-10-04 09:10:32'),('8555cfae-d62f-4353-9971-5143d67aa1e3','37515078-f53c-4dbf-9c9f-a44ec7635159','013095aa-0f4d-4c32-b30e-229a587e52ad','2020-09-25 09:36:54'),('88ac0cac-c1e0-4d8e-a7e9-9154af6769ee','e14e2c33-a45d-49bc-9502-a9bb89b587be','2f9a3f67-6ef3-4eac-b9a1-c0e898718d0c','2020-10-04 09:10:32'),('88e9413e-c44b-4e93-af4f-ce8ab148e6fd','37515078-f53c-4dbf-9c9f-a44ec7635159','bb5ca869-0303-4fc0-b067-936cba7d1cc8','2020-09-25 09:36:54'),('9211c4e7-cfbb-4ea5-9715-b9908170969f','37515078-f53c-4dbf-9c9f-a44ec7635159','c198d1cb-ad4d-4001-9375-9ec8ee04053d','2020-09-25 09:36:54'),('9277fb1a-249b-45d7-a514-0350eee8b506','b125dbb8-459e-409f-bd1f-d17966568eda','d60faf3e-9a72-49d5-b02d-a67bfeff07fa','2020-04-06 07:16:20'),('94224cb4-5586-42e1-a88d-0c9f4febfa5a','b125dbb8-459e-409f-bd1f-d17966568eda','4caeb861-354c-45f6-98b4-59f486beb511','2020-04-06 07:16:20'),('949163a4-3ead-42a5-979a-7f3f455208de','37515078-f53c-4dbf-9c9f-a44ec7635159','d41c2bc3-454c-4f62-84fe-97825d5cf8a7','2020-09-25 09:36:54'),('94cf7cf0-6929-4e7c-a8dd-09932e1b06ad','b125dbb8-459e-409f-bd1f-d17966568eda','90b3be91-5e9d-42f8-81fb-0c9ef3014faa','2020-10-12 21:33:59'),('95ac5cc1-f286-444f-8864-3026a0958a9f','e14e2c33-a45d-49bc-9502-a9bb89b587be','2f9a3f67-6ef3-4eac-b9a1-c0e898718d0c','2020-10-04 09:10:16'),('977a6c77-7665-43b5-a29e-c5af6186070d','e14e2c33-a45d-49bc-9502-a9bb89b587be','2eeaa020-74d5-4c4b-9849-2cf4bd68fed9','2020-10-04 09:10:32'),('979eb049-5ff2-4cd2-a4d9-c6d76b9f7e02','b125dbb8-459e-409f-bd1f-d17966568eda','15bb6aff-2e3b-490a-a21f-0167ae0ebc0d','2020-04-06 07:16:20'),('9af322d3-b337-452a-bf4a-bfd202d61c98','e14e2c33-a45d-49bc-9502-a9bb89b587be','013095aa-0f4d-4c32-b30e-229a587e52ad','2020-10-08 16:38:09'),('9af95591-dd4c-4580-a659-063520943f06','b125dbb8-459e-409f-bd1f-d17966568eda','c095273c-7917-4503-8569-6a67a9979d56','2020-10-12 21:33:59'),('9c234f07-d722-4a56-919c-0000ee41a84c','b125dbb8-459e-409f-bd1f-d17966568eda','90b3be91-5e9d-42f8-81fb-0c9ef3014faa','2020-04-06 07:16:20'),('9e4db3cf-c439-41a7-b282-68255d4afb26','e14e2c33-a45d-49bc-9502-a9bb89b587be','2f9a3f67-6ef3-4eac-b9a1-c0e898718d0c','2020-10-08 16:38:09'),('9ef39023-7186-4728-b658-c6823bda1d54','b125dbb8-459e-409f-bd1f-d17966568eda','65734896-90c5-4b48-b9e8-dee47a74a297','2020-04-06 07:16:20'),('9ef77c1a-11a6-4ca4-8557-c6a3cdd2a766','b125dbb8-459e-409f-bd1f-d17966568eda','346df872-8964-4455-8afd-ffa6308fb18a','2020-04-06 07:16:20'),('a332cbd1-0f7f-4285-8453-e602edc25fa2','b125dbb8-459e-409f-bd1f-d17966568eda','47697e92-e199-4420-a2c2-09ec1b08cb9d','2020-10-12 21:33:59'),('a3720a15-b40e-41d6-8ea4-70be067738b5','b125dbb8-459e-409f-bd1f-d17966568eda','f1ea1abb-3dde-4196-b054-2ae2fcfe7c23','2020-10-12 21:33:59'),('a436fbea-42b3-4674-b338-038973317cb2','e14e2c33-a45d-49bc-9502-a9bb89b587be','ccef525e-3392-45f8-969f-d552b142dc0f','2020-10-04 09:10:16'),('a4c8efd0-db33-4bb0-aa38-c48b4af2d039','b125dbb8-459e-409f-bd1f-d17966568eda','b7348d63-c4d3-406d-9e46-543346674275','2020-04-06 07:16:20'),('a510514e-00e6-41be-b38e-7cade570f40d','37515078-f53c-4dbf-9c9f-a44ec7635159','f9f4d9f4-a2f5-430c-9f2d-6c8e650a8c39','2020-09-25 09:36:54'),('a54820d1-34d2-4a68-bb3f-8031895da13f','37515078-f53c-4dbf-9c9f-a44ec7635159','2eeaa020-74d5-4c4b-9849-2cf4bd68fed9','2020-09-25 09:36:54'),('a74f23f2-2069-46dc-9acb-778dbb499269','e14e2c33-a45d-49bc-9502-a9bb89b587be','013095aa-0f4d-4c32-b30e-229a587e52ad','2020-10-04 09:10:16'),('a84c8b12-3762-4169-adba-ebd564d5c71a','b125dbb8-459e-409f-bd1f-d17966568eda','f1ea1abb-3dde-4196-b054-2ae2fcfe7c23','2020-04-06 07:16:20'),('a8f0d869-182d-484e-b7dd-8f673b5404b8','b125dbb8-459e-409f-bd1f-d17966568eda','2446fd0d-11ba-44aa-9128-531e38ec3b7a','2020-04-06 07:16:20'),('a9b34d39-21cb-4185-8fba-c6d58b7215a0','b125dbb8-459e-409f-bd1f-d17966568eda','390ded0e-9f48-40a7-a841-791c203f22ae','2020-10-12 21:33:59'),('a9ee2f5c-9a27-40a0-b8f3-2f550e78b149','b125dbb8-459e-409f-bd1f-d17966568eda','5695ed19-5620-4da4-8cb0-159f34ae6591','2020-04-06 07:16:20'),('aa0acc97-f626-4225-9f05-f764a00b57c4','b125dbb8-459e-409f-bd1f-d17966568eda','d41c2bc3-454c-4f62-84fe-97825d5cf8a7','2020-10-12 21:33:59'),('aa171075-6704-423a-be34-93f3d82c6514','e14e2c33-a45d-49bc-9502-a9bb89b587be','290c0240-0914-487c-b4e9-6635bf5ebfec','2020-10-08 16:38:09'),('abe419a6-64ce-428d-96f6-bb24fc098345','37515078-f53c-4dbf-9c9f-a44ec7635159','27acf73b-2fcb-451b-bdc4-e11e5ab41e2a','2020-09-25 09:36:54'),('acfae926-b44b-42d6-9c08-5e09091ed3bb','b125dbb8-459e-409f-bd1f-d17966568eda','9ce621a0-ee2c-4cf6-b7bd-012a1a01ba63','2020-04-06 07:16:20'),('ad75e874-fc05-46bc-b076-e1300c04e89e','e14e2c33-a45d-49bc-9502-a9bb89b587be','346df872-8964-4455-8afd-ffa6308fb18a','2020-10-04 09:10:16'),('adcc8d7b-7d2f-4856-950e-315ad0f9cf1c','e14e2c33-a45d-49bc-9502-a9bb89b587be','2446fd0d-11ba-44aa-9128-531e38ec3b7a','2020-10-08 16:38:09'),('ae973ead-2777-4c08-be58-a064e2f2295d','b125dbb8-459e-409f-bd1f-d17966568eda','8f393e44-b585-4875-866d-71f88fea9659','2020-10-12 21:33:59'),('af809abf-243e-4ffa-b3ea-6b7bc61344c2','b125dbb8-459e-409f-bd1f-d17966568eda','26694831-fc81-4590-9095-af7e55b9819a','2020-04-06 07:16:20'),('b016e6b1-b225-4f47-9116-2c04a4a73a74','b125dbb8-459e-409f-bd1f-d17966568eda','c198d1cb-ad4d-4001-9375-9ec8ee04053d','2020-10-12 21:33:59'),('b048b999-a7ba-4774-84dc-09cb2f2cec61','37515078-f53c-4dbf-9c9f-a44ec7635159','145cb90b-d205-40f6-8a2d-703f41ed1feb','2020-09-25 09:36:54'),('b05b886b-b0cb-4f6c-9384-301a60753033','37515078-f53c-4dbf-9c9f-a44ec7635159','2f9a3f67-6ef3-4eac-b9a1-c0e898718d0c','2020-09-25 09:36:54'),('b110bdb9-0245-452b-9c6a-3a4ac2852e68','b125dbb8-459e-409f-bd1f-d17966568eda','f9f4d9f4-a2f5-430c-9f2d-6c8e650a8c39','2020-04-06 07:16:20'),('b760a1a4-c16a-4f8d-a9dd-601d1f3f4eb1','b125dbb8-459e-409f-bd1f-d17966568eda','47697e92-e199-4420-a2c2-09ec1b08cb9d','2020-04-06 07:16:20'),('b7bbaf5e-7002-48c2-a4b0-c47201c16065','b125dbb8-459e-409f-bd1f-d17966568eda','bb5ca869-0303-4fc0-b067-936cba7d1cc8','2020-10-12 21:33:59'),('ba260ea8-5fbb-4fba-9fdc-2be76d666e6b','e14e2c33-a45d-49bc-9502-a9bb89b587be','c198d1cb-ad4d-4001-9375-9ec8ee04053d','2020-10-04 09:10:16'),('badcb518-85a0-47a7-b38b-ed7ab15f5b6b','b125dbb8-459e-409f-bd1f-d17966568eda','27acf73b-2fcb-451b-bdc4-e11e5ab41e2a','2020-10-12 21:33:59'),('bc221ed9-3393-4f87-ba80-5b4336f2ac19','b125dbb8-459e-409f-bd1f-d17966568eda','24b7b13c-f00f-4e6b-a221-fe2d780e4d4f','2020-04-06 07:16:20'),('bd4feb99-cae8-4831-95ac-9df70962c90d','e14e2c33-a45d-49bc-9502-a9bb89b587be','346df872-8964-4455-8afd-ffa6308fb18a','2020-10-08 16:38:09'),('bdb92e20-3e8f-48a4-a436-a3195ce72a2e','37515078-f53c-4dbf-9c9f-a44ec7635159','90b3be91-5e9d-42f8-81fb-0c9ef3014faa','2020-09-25 09:36:54'),('c138bf70-7ee0-4970-bb20-e5dcdefa7f91','b125dbb8-459e-409f-bd1f-d17966568eda','145cb90b-d205-40f6-8a2d-703f41ed1feb','2020-10-12 21:33:59'),('c4e9360b-713d-4405-aaf7-bd2c6d6ffd36','b125dbb8-459e-409f-bd1f-d17966568eda','2eeaa020-74d5-4c4b-9849-2cf4bd68fed9','2020-10-12 21:33:59'),('c7e72ca0-b2b6-4f2f-ba4b-338daab21a3c','37515078-f53c-4dbf-9c9f-a44ec7635159','390ded0e-9f48-40a7-a841-791c203f22ae','2020-09-25 09:36:54'),('ca57141d-2edb-4d0c-99cd-a730484e0c87','e14e2c33-a45d-49bc-9502-a9bb89b587be','2446fd0d-11ba-44aa-9128-531e38ec3b7a','2020-10-04 09:10:16'),('cb0eac88-9846-4bc5-bda1-1bf4bf2269db','e14e2c33-a45d-49bc-9502-a9bb89b587be','290c0240-0914-487c-b4e9-6635bf5ebfec','2020-10-04 09:10:16'),('cf936f5c-a51b-48fa-8060-3424ba3994ed','b125dbb8-459e-409f-bd1f-d17966568eda','8180e320-e2bf-470c-bb42-80fb5bf9f5c3','2020-10-12 21:33:59'),('d1490978-3999-444e-8f6e-3de0aeea861a','b125dbb8-459e-409f-bd1f-d17966568eda','8f393e44-b585-4875-866d-71f88fea9659','2020-04-06 07:16:20'),('d2b25df9-cdea-4100-9fdf-e233b3b3765d','b125dbb8-459e-409f-bd1f-d17966568eda','0545d9d1-c82c-44c2-85e5-0b6ac4042515','2020-10-12 21:33:59'),('d3c9d7a7-2392-4a19-a61d-63aa800773c2','b125dbb8-459e-409f-bd1f-d17966568eda','390ded0e-9f48-40a7-a841-791c203f22ae','2020-04-06 07:16:20'),('d3f47dd6-5758-400e-bdac-640fd5f2f767','b125dbb8-459e-409f-bd1f-d17966568eda','075224a7-1805-4f2f-a325-157effaf0004','2020-04-06 07:16:20'),('d615d85b-8ed3-4fe2-ac61-d7e9ce672278','37515078-f53c-4dbf-9c9f-a44ec7635159','65734896-90c5-4b48-b9e8-dee47a74a297','2020-09-25 09:36:54'),('db28f4c7-6b95-4208-9d7c-6eba1c56456f','b125dbb8-459e-409f-bd1f-d17966568eda','7141c2e9-6d50-46b6-94e8-100466b7249f','2020-10-12 21:33:59'),('dc48999e-8fe4-4370-890f-e981c6fc551a','b125dbb8-459e-409f-bd1f-d17966568eda','2ae13993-9501-46d5-8473-fe45fee57f3b','2020-04-06 07:16:20'),('dc5d0eb4-a0d8-4161-b608-e1f211a04180','b125dbb8-459e-409f-bd1f-d17966568eda','27acf73b-2fcb-451b-bdc4-e11e5ab41e2a','2020-04-06 07:16:20'),('dec65661-4c8f-47b8-a7cc-fc4b89961609','37515078-f53c-4dbf-9c9f-a44ec7635159','84b9b525-aa44-4b16-9900-adca26115a37','2020-09-25 09:36:54'),('e066a9a1-2fb8-49d4-85d6-d74d64cf5485','e14e2c33-a45d-49bc-9502-a9bb89b587be','346df872-8964-4455-8afd-ffa6308fb18a','2020-10-04 09:10:32'),('e9cf649c-905d-47d1-84ba-089d97e46405','b125dbb8-459e-409f-bd1f-d17966568eda','15bb6aff-2e3b-490a-a21f-0167ae0ebc0d','2020-10-12 21:33:59'),('ea67a8c7-b4de-4e49-ba84-df5c3314579f','37515078-f53c-4dbf-9c9f-a44ec7635159','290c0240-0914-487c-b4e9-6635bf5ebfec','2020-09-25 09:36:54'),('eb8d5230-a7d8-4ca3-9acc-c9aa5c55edca','b125dbb8-459e-409f-bd1f-d17966568eda','d41c2bc3-454c-4f62-84fe-97825d5cf8a7','2020-04-06 07:16:20'),('ede3fe8f-acba-49ad-816e-663c20aff1f2','b125dbb8-459e-409f-bd1f-d17966568eda','290c0240-0914-487c-b4e9-6635bf5ebfec','2020-04-06 07:16:20'),('f016191f-d82b-46e0-b4d9-5a2c7a2e988f','b125dbb8-459e-409f-bd1f-d17966568eda','9ce621a0-ee2c-4cf6-b7bd-012a1a01ba63','2020-10-12 21:33:59'),('f1824279-d616-4cad-88d3-a39f81791d9a','37515078-f53c-4dbf-9c9f-a44ec7635159','9ce621a0-ee2c-4cf6-b7bd-012a1a01ba63','2020-09-25 09:36:54'),('f590b998-4c24-44ce-93c6-2159604a632d','b125dbb8-459e-409f-bd1f-d17966568eda','03dc1cbf-ef44-4326-a7dc-10fe16d22dad','2020-04-06 07:16:20'),('fb936e7d-ace4-4dd4-9b7f-07513271207f','37515078-f53c-4dbf-9c9f-a44ec7635159','d60faf3e-9a72-49d5-b02d-a67bfeff07fa','2020-09-25 09:36:54'),('fef386a7-6ccf-4c6b-ab76-f66670a494c7','b125dbb8-459e-409f-bd1f-d17966568eda','d60faf3e-9a72-49d5-b02d-a67bfeff07fa','2020-10-12 21:33:59');
/*!40000 ALTER TABLE `sys_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_rotation_chart`
--

DROP TABLE IF EXISTS `sys_rotation_chart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_rotation_chart` (
  `id` varchar(64) NOT NULL COMMENT '轮播图主键id',
  `url` varchar(500) DEFAULT NULL COMMENT '轮播图广告跳转地址',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `file_url` varchar(500) DEFAULT NULL COMMENT '图片文件地址',
  `sort` tinyint DEFAULT NULL COMMENT '排序位置',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `create_id` varchar(64) DEFAULT NULL COMMENT '创建用户',
  `update_id` varchar(64) DEFAULT NULL COMMENT '更新用户',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='轮播图表结构';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_rotation_chart`
--

LOCK TABLES `sys_rotation_chart` WRITE;
/*!40000 ALTER TABLE `sys_rotation_chart` DISABLE KEYS */;
INSERT INTO `sys_rotation_chart` VALUES ('5d76f7e3-eda1-477b-b23e-b83c6ae3abb4','http://www.cjree.cn','文件管理系统','https://wxy-oss.oss-cn-beijing.aliyuncs.com/2020/10/15/cbbb8fb9417846c5bbbd3a3b81028147smallfaa3728c8a225f771e19c586e9172ab41574854075.jpg',3,'文件管理系统','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7',NULL,NULL,'2020-10-15 17:31:32'),('90ec9050-556d-4de2-8752-b267c4b26e94','http://www.cjree.cn:5556','后台管理系统','https://wxy-oss.oss-cn-beijing.aliyuncs.com/2020/10/15/852c528950d841ac9a5d7522d7fe16f3smallfb5eb76bfad671a169013c54fb79e5d51595173351.jpg',2,'后台管理系统','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7',NULL,NULL,'2020-10-15 17:31:10'),('c9a4bb53-df94-4b2f-89ec-2bb6942b53d2','http://www.cjree.cn:5555','健康档案管理系统','https://wxy-oss.oss-cn-beijing.aliyuncs.com/2020/10/15/d8356a9b9c214a16b38a04a6f0a2183920200415192716u=1337124397,3601513508&fm=26&gp=0.jpg',1,'健康档案管理系统','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7',NULL,NULL,'2020-10-15 17:32:08');
/*!40000 ALTER TABLE `sys_rotation_chart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `id` varchar(64) NOT NULL COMMENT '用户id',
  `username` varchar(50) NOT NULL COMMENT '账户名称',
  `salt` varchar(20) DEFAULT NULL COMMENT '加密盐值',
  `password` varchar(200) NOT NULL COMMENT '用户密码密文',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号码',
  `dept_id` varchar(64) DEFAULT NULL COMMENT '部门id',
  `real_name` varchar(60) DEFAULT NULL COMMENT '真实名称',
  `nick_name` varchar(60) DEFAULT NULL COMMENT '昵称',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱(唯一)',
  `status` tinyint DEFAULT '1' COMMENT '账户状态(1.正常 2.锁定 )',
  `sex` tinyint DEFAULT '1' COMMENT '性别(1.男 2.女)',
  `deleted` tinyint DEFAULT '1' COMMENT '是否删除(1未删除；0已删除)',
  `create_id` varchar(64) DEFAULT NULL COMMENT '创建人',
  `update_id` varchar(64) DEFAULT NULL COMMENT '更新人',
  `create_where` tinyint DEFAULT '1' COMMENT '创建来源(1.web 2.android 3.ios )',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES ('02119aa6-e7b1-480a-b6d7-0c34a3309725','wxy','e3ebf797c62247039a7d','2e046e4f31ed2d2a25e0f834c60830dc','18955007260','fab724d7-be7c-48d0-b37a-d94edb56a4f1',NULL,NULL,NULL,2,1,1,NULL,'9a26f5f1-cbd2-473d-82db-1d6dcf4598f7',1,'2020-09-28 19:14:16','2020-10-18 15:28:08'),('69f2c40f-1643-4db1-8d05-d1f525c56ac5','ybl','8e54d61489ac4940ae6a','61a172007be2741fc15098d1220fc3c5','189555077261','fab724d7-be7c-48d0-b37a-d94edb56a4f1',NULL,NULL,NULL,1,1,0,NULL,'9a26f5f1-cbd2-473d-82db-1d6dcf4598f8',1,'2020-10-02 17:05:47','2020-10-02 17:07:18'),('9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','admin','324ce32d86224b00a02b','3b0b0d26f201325e4916c5bc3e47a066','18955007261','fab724d7-be7c-48d0-b37a-d94edb56a4f1','王星宇','星宇呀','wxy18955007261@163.com',1,1,1,NULL,'9a26f5f1-cbd2-473d-82db-1d6dcf4598f7',1,'2020-09-27 19:38:05','2020-10-06 19:42:52'),('9cda60c5-557f-4747-9133-d3904d6589a2','www','4478e9e77b32405e8880','a24f3da8536602b865a124a321dd2102','www','09936ec4-cef1-44b0-be40-1d9adce44edd',NULL,NULL,NULL,1,1,1,NULL,'9a26f5f1-cbd2-473d-82db-1d6dcf4598f7',1,'2020-10-06 19:52:58','2020-10-07 10:04:42');
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_role`
--

DROP TABLE IF EXISTS `sys_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_role` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `user_id` varchar(64) DEFAULT NULL COMMENT '用户id',
  `role_id` varchar(64) DEFAULT NULL COMMENT '角色id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_role`
--

LOCK TABLES `sys_user_role` WRITE;
/*!40000 ALTER TABLE `sys_user_role` DISABLE KEYS */;
INSERT INTO `sys_user_role` VALUES ('3635265a-c67d-4b0a-b6a6-a826f258ddc2','9a26f5f1-cbd2-473d-82db-1d6dcf4598f7','b125dbb8-459e-409f-bd1f-d17966568eda','2020-10-15 15:32:54'),('5264f128-2807-49af-9d92-301dd5d42ddc','9cda60c5-557f-4747-9133-d3904d6589a2','37515078-f53c-4dbf-9c9f-a44ec7635159','2020-10-09 13:02:02');
/*!40000 ALTER TABLE `sys_user_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-24 16:53:01
