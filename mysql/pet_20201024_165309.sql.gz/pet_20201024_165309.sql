-- MySQL dump 10.13  Distrib 8.0.20, for Linux (x86_64)
--
-- Host: localhost    Database: pet
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pet_config_password_encrypt_key`
--

DROP TABLE IF EXISTS `pet_config_password_encrypt_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_config_password_encrypt_key` (
  `wxy_key` varchar(100) NOT NULL DEFAULT '' COMMENT '密码加密密钥',
  `id` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='syslog配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_config_password_encrypt_key`
--

LOCK TABLES `pet_config_password_encrypt_key` WRITE;
/*!40000 ALTER TABLE `pet_config_password_encrypt_key` DISABLE KEYS */;
INSERT INTO `pet_config_password_encrypt_key` VALUES ('9A8159B49AB10B4BA55BC477B1C0E79E',1);
/*!40000 ALTER TABLE `pet_config_password_encrypt_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_file`
--

DROP TABLE IF EXISTS `pet_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_file` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '文件存储主键id',
  `file_url` varchar(255) NOT NULL COMMENT '文件地址',
  `file_name` varchar(255) NOT NULL COMMENT '文件名称',
  `extension_name` varchar(20) NOT NULL COMMENT '文件扩展名',
  `original_name` varchar(255) NOT NULL COMMENT '原始文件名称',
  `type` tinyint NOT NULL DEFAULT '2' COMMENT '文件类型(1：其他类型文件；2:图片；3：视频文件；)',
  `size` varchar(10) NOT NULL COMMENT '文件大小',
  `deleted` tinyint(1) NOT NULL COMMENT '0未删除,1已删除',
  `create_id` int NOT NULL COMMENT '创建用户id',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件信息存储表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_file`
--

LOCK TABLES `pet_file` WRITE;
/*!40000 ALTER TABLE `pet_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_log`
--

DROP TABLE IF EXISTS `pet_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_log` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int DEFAULT NULL COMMENT '用户id',
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `operation` varchar(50) DEFAULT NULL COMMENT '用户操作',
  `time` int DEFAULT NULL COMMENT '响应时间',
  `method` varchar(200) DEFAULT NULL COMMENT '请求方法',
  `params` varchar(5000) DEFAULT NULL COMMENT '请求参数',
  `ip` varchar(64) DEFAULT NULL COMMENT 'IP地址',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_log`
--

LOCK TABLES `pet_log` WRITE;
/*!40000 ALTER TABLE `pet_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_rotation_chart`
--

DROP TABLE IF EXISTS `pet_rotation_chart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_rotation_chart` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '轮播图主键id',
  `url` varchar(255) NOT NULL COMMENT '轮播图跳转地址',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `file_url` varchar(255) NOT NULL COMMENT '文件url',
  `file_id` int NOT NULL COMMENT '图片文件id',
  `sort` tinyint NOT NULL COMMENT '排序位置',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `create_id` int NOT NULL COMMENT '创建用户',
  `update_id` int NOT NULL COMMENT '更新用户',
  `deleted` tinyint(1) NOT NULL COMMENT '0未删除,1已删除',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='轮播图表结构';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_rotation_chart`
--

LOCK TABLES `pet_rotation_chart` WRITE;
/*!40000 ALTER TABLE `pet_rotation_chart` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_rotation_chart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_test`
--

DROP TABLE IF EXISTS `pet_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_test` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `user` varchar(50) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '密码',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '0未删除,1已删除',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '更新时间',
  `version` int NOT NULL DEFAULT '0' COMMENT '版本',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_test`
--

LOCK TABLES `pet_test` WRITE;
/*!40000 ALTER TABLE `pet_test` DISABLE KEYS */;
INSERT INTO `pet_test` VALUES (1,'string','string',0,'2020-10-17 19:21:16','2020-10-17 19:21:16',0),(2,'admin','333333',0,'2020-10-17 19:24:31','2020-10-17 19:24:31',1),(3,'tset','333333',0,'2020-10-17 19:30:24','2020-10-17 19:30:24',1),(4,'tys','333333',0,'2020-10-17 19:31:17','2020-10-17 19:31:17',0),(5,'tyss','333333',0,'2020-10-17 19:32:27','2020-10-17 19:32:27',0),(6,'safa','afa',0,'2020-10-17 19:33:24','2020-10-17 19:33:24',0),(7,'aaaa','afaa',0,'2020-10-17 19:34:29','2020-10-17 19:34:29',0),(8,'3333','fc51212a3528ac91f333b615af51e225',0,'2020-10-17 19:38:57','2020-10-17 19:38:57',0);
/*!40000 ALTER TABLE `pet_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_user`
--

DROP TABLE IF EXISTS `pet_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_user` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(50) NOT NULL DEFAULT '' COMMENT '密码',
  `wechat` varchar(50) NOT NULL DEFAULT '' COMMENT '微信',
  `phone` varchar(20) NOT NULL DEFAULT '' COMMENT '手机号',
  `photo_url` varchar(255) NOT NULL DEFAULT '' COMMENT '照片url',
  `photo_id` int unsigned NOT NULL DEFAULT '1' COMMENT '头像地址',
  `statu` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '0禁用,1启用',
  `creat_id` int unsigned NOT NULL DEFAULT '1' COMMENT '创建者id',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '''逻辑删除 1（true）已删除， 0（false）未删除''',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `photo` (`photo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_user`
--

LOCK TABLES `pet_user` WRITE;
/*!40000 ALTER TABLE `pet_user` DISABLE KEYS */;
INSERT INTO `pet_user` VALUES (1,'admin','7b4810e498356f29a2d4bef4e6eda03f','wxy18955007261','18955007261','',1,1,1,0,'2020-10-16 16:32:57','2020-10-16 16:32:59'),(11,'17856816110','de4a3ab0bafe820d1e5447bfc9453563','','17856816110','',1,1,1,0,'2020-10-20 18:56:58','2020-10-20 18:56:58'),(12,'13856279897','f40a6474d6c0f020c291cf65b64bc6b5','','13856279897','',1,1,1,0,'2020-10-20 21:38:04','2020-10-20 21:38:04'),(13,'17856274681','cb4cbae32199a47e6d79f599df74d732','','17856274681','',1,1,1,0,'2020-10-21 08:46:17','2020-10-21 08:46:17'),(14,'1','fe9803f8d207755523417ada447c4862','','18851975662','',1,1,1,0,'2020-10-23 13:12:14','2020-10-23 13:12:14'),(19,'18955050308','345463b05d6e2093e84cc49deb0d1ba6','','18955050308','',1,1,1,0,'2020-10-23 13:23:15','2020-10-23 13:23:15'),(20,'万事胜意','4af9995a0c73805215510915fea00980','','16605532658','',1,1,1,0,'2020-10-23 17:38:42','2020-10-23 17:38:42');
/*!40000 ALTER TABLE `pet_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-24 16:53:09
